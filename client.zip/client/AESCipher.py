from Crypto.Cipher import AES
import base64

#this function get string and key and make string encrypted
def encrypt_val(clear_text,key):
    enc_secret = AES.new(key[:32])
    tag_string = (str(clear_text) +
                  (AES.block_size -
                   len(str(clear_text)) % AES.block_size) * "\0")
    cipher_text = base64.urlsafe_b64encode(enc_secret.encrypt(tag_string))
    return cipher_text

#this function get string and key and decrypt string
def decrypt_val(cipher_text,key):
    dec_secret = AES.new(key[:32])
    raw_decrypted = dec_secret.decrypt(base64.urlsafe_b64decode(cipher_text))
    clear_val = raw_decrypted.decode().rstrip("\0")
    return clear_val


