from client import client
import encryptFiles
from pathlib import Path
import hmac
import os
from AESCipher import encrypt_val
from AESCipher import decrypt_val
import ntpath
import base64

#THIS CLASS is used the client class function and the encryptfiles calss and supplied function that opprate on files on the server in ecrypted way
class encryptedClient():
    def __init__(self):
        self.client = client()
        self.macFile = None

    #this fucntion get file name and upload to server after encryption on the file name and the content of file
    def uploadFileEncrypt(self,fileName):
        fileName = os.path.relpath(fileName,str(Path().absolute()))
        newfile = fileName.split('\\')
        justname = newfile[len(newfile) - 1]
        if self.findFileNameinMyFiles(justname)==True:
            return 'already exists'
        out_filename = encrypt_val(justname,self.client.k2)
        encryptFile = encryptFiles.encrypt_file(self.client.k2 , fileName, out_filename)
        file = open(encryptFile)
        text = file.read()
        file.close()
        macAns = hmac.new(self.client.k3, text).hexdigest()
        encryptFileSize = str(os.path.getsize(encryptFile))
        self.addFileName(justname,encryptFileSize, macAns)
        self.client.uploadFile(encryptFile)
        if os.path.exists(encryptFile):
            try:
                os.remove(encryptFile)
            except OSError, e:
                print ("Error: %s - %s." % (e.encryptFile, e.strerror))

    # this fucntion get file name and download to client after decryption on the file name and the content of file
    def downloadFileEncrypt(self, filename):
        out_filename = encrypt_val(filename,self.client.k2)
        self.client.downloadFile(out_filename)
        file = open(out_filename)
        text = file.read()
        file.close()
        macAns = hmac.new(self.client.k3, text)
        tao = self.findTAOByFileName(filename)
        if tao == "false":
            print "tao not found"
        else:
            print tao
            print macAns.hexdigest()
            if (macAns.hexdigest() == tao):
                encryptFiles.decrypt_file(self.client.k2, out_filename, filename)
                os.remove(str(Path().absolute())+'\\'+out_filename)
                return True
            else:
                print "file has been change"
                return False
        if os.path.exists(out_filename):
            try:
                os.remove(out_filename)
            except OSError, e:
                print ("Error: %s - %s." % (e.out_filename, e.strerror))

####################################################################################################
#THIS FUNCTION JUST FIND THE SIZE OF FILE IN THE SERVER
    def get_total_size(self, directory):
        size = 0
        for filename in self.client.ftp_client.nlst(directory):
            try:
                self.client.ftp_client.cwd(filename)
                size += self.get_total_size(filename)
            except:
                self.client.ftp_client.voidcmd('TYPE I')
                size += self.client.ftp_client.size(filename)
        return size

#THIS FUNCTION IS CHECKING ALL THE FILES IN THE SERVER IF THEM HAVE BEEN CHANGE:
#IF THE FILES NOT CHANE RETURN -  "files not change"
#ELSE - return a string that contain all the changes in the files (str)
    def checkIfFilesChange(self):
        myFileOld = open(self.client.myFile)#, 'w+')
        readmyFileOld = myFileOld.readlines()
        myFileOld.close()
        str =''
        filesIsChange = False
        for line in readmyFileOld:
            currLine = line.split(" ")
            filename = currLine[0]
            encryptfilename = encrypt_val(filename,self.client.k2)
            filesize = int(currLine[1])
            if not self.client.exists(encryptfilename):
                str += "file "+filename+" not exist\n"
                filesIsChange = True

            else:
                sizeInServer = self.get_total_size(encryptfilename)
                if sizeInServer != filesize:
                    str+= "The size of " +filename+" has been changed!!!\n"
                    filesIsChange = True

        if filesIsChange:
            return str
        return "Your files didn\'t change :-)"

#this function upload the file of file to the server - NEED TO BE CALLES UPPON LOGOUT
    def uploadMyFile(self):
        out_filename = encrypt_val(self.client.myFile, self.client.k2)
        encryptFile = encryptFiles.encrypt_file(self.client.k2, self.client.myFile, out_filename)
        file = open(encryptFile)
        text = file.read()
        file.close()
        self.macFile = hmac.new(self.client.k3, text).hexdigest()
        self.client.uploadFile(encryptFile)
        if os.path.exists(encryptFile):
            try:
                os.remove(encryptFile)
            except OSError, e:
                print ("Error: %s - %s." % (e.encryptFile, e.strerror))


#THIS FUNCTION DOWNLOADS THE FILE OF FILES FROM THE SERVER AND CHECK IF THE MAC HAVE BEEN CHANGE - SHOULD BY CALLES UPPON LOGIN
    def downLoadMyFile(self):
        out_filename = encrypt_val(self.client.myFile, self.client.k2)
        self.client.downloadFile(out_filename)
        file = open(out_filename)
        text = file.read()
        file.close()
        #myFileOld = open(self.client.myFile)
        #readmyFileOld = file.read()
        #myFileOld.close()
        macAns = hmac.new(self.client.k3, text)
        if self.macFile == "false":
            print "tao not found"
        else:
            #check if the mac is the same
            #print macAns.hexdigest()
            if (macAns.hexdigest() == self.macFile):
                encryptFiles.decrypt_file(self.client.k2, out_filename, self.client.myFile)
                return True
            else:
                print "file has been changed"
                return False
##################################################################################################################################

    #this function return list on files on that exist on server
    def showDirFilesEncrypt(self):
        filesList = self.client.showDirFiles()
        if filesList == 'No files in this directory':
            return 'No files in this directory'
        newList = []
        for file in filesList:
            newfile = decrypt_val(file, self.client.k2)
            newList.append(newfile)
        return newList


    #this function add file name and more details about file to the file of files
    def addFileName(self,filename,encryptFileSize,macAns):
        file = open(self.client.myFile,'a')
        file.write(filename + " " + encryptFileSize + " " + macAns+"\n")
        file.close()

    #this function get file name and check if this file exists in the file of files
    def findFileNameinMyFiles(self, filename):
        file = open(self.client.myFile, 'r')
        readFile = file.read()
        file.close()
        userpassList = readFile.split('\n')
        for line in userpassList:
            curr = line.split(' ')
            if curr[0] == filename:
                return True
                break
        else:
            return False

    #this function return the TAO of file name in the file of files if it exists
    def findTAOByFileName(self,filename):
        file = open(self.client.myFile)
        readFile = file.read()
        file.close()
        userpassList = readFile.split('\n')
        for line in userpassList:
            curr = line.split(' ')
            if curr[0] == filename:
                return curr[2]
                break
        else:
            return False

    # this function return the size of file name in the file of files if it exists
    def findSizeByFileName(self, filename):
        file = open(self.client.myFile)
        readFile = file.read()
        file.close()
        userpassList = readFile.split('\n')
        for line in userpassList:
            curr = line.split(' ')
            if curr[0] == filename:
                return curr[1]
                break
        else:
            return False

    # this function delete the line of file name in the file of files if it exists
    def findLineAndDelete(self, filename):
        file = open(self.client.myFile)
        lines = file.readlines()
        file.close()

        file = open(self.client.myFile,'w')
        for line in lines:
            curr = line.split(' ')
            if curr[0] != filename:
                file.write(line)
        file.close()

    #this function get file name and delete on server
    def deleteFileEncrypt(self, filename):
        encrypted_filename = encrypt_val(filename, self.client.k2)
        self.client.deleteFile(encrypted_filename)
        self.findLineAndDelete(filename)

    # this function get file name and rename on server
    def renameFileEncrypt(self, oldFile, newFile):
        encrypted_oldfilename = encrypt_val(oldFile, self.client.k2)
        encrypted_newfilename = encrypt_val(newFile, self.client.k2)
        self.client.renameFile(encrypted_oldfilename, encrypted_newfilename)
        size = self.findSizeByFileName(oldFile)
        TAO = self.findTAOByFileName(oldFile)
        self.findLineAndDelete(oldFile)
        self.addFileName(newFile,size,TAO)

    # this function get file name and overwrite on server
    def overwriteFileEncrypt(self, fileName):
        justname =  ntpath.basename(fileName)
        encrypted_oldfilename = encrypt_val(justname, self.client.k2)
        if self.client.exists(encrypted_oldfilename):
            self.deleteFileEncrypt(justname)
            self.uploadFileEncrypt(fileName)
            return True
        else:
            self.uploadFileEncrypt(fileName)
            return True

    # this function check if the file of files is on the server
    def isMyFileOnServer(self):
        encrypted_oldfilename = encrypt_val(self.client.myFile, self.client.k2)
        if self.client.exists(encrypted_oldfilename):
            return True
        return False

