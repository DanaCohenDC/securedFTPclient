from Tkinter import *
from Tkinter import Listbox
import Tkinter as TK
self = Tk()
import tkFileDialog
import ntpath
from encryptdedClient import encryptedClient

encryptedclient = encryptedClient()

self.title("Secured FTP Client") #stands for "corraletion generator"
self.geometry("600x500")

securedLabel = Label(self, text='Secured FTP Client')
securedLabel.place(x=140, y=100)
securedLabel.config(font=('Courier', 20))

#globals
global username
global password
global window
global LB


#functions
#when we log out we need to close the GUI window and upload the file that described clients files
def closeWindow():
    encryptedclient.uploadMyFile()
    global canloginLabel
    if( canloginLabel is not None):
        canloginLabel.destroy()
    window.destroy()

#gets the username the user entered
def getUserName():
    global username
    username = usernameEntry.get()

#gets the password the user entered
def getPassword():
    global password
    password = passwordEntry.get()

#check password and username entered are valid
def checkValidity():
    global username
    global password
    getUserName()
    getPassword()
    if ( (not username) or (not password)):
        missingLabel = Label(self, text='Please enter both username and password')
        missingLabel.place(x=10, y=470)
        return False
    return True

#register to server
def register():
    if (checkValidity()== True):
        msg = encryptedclient.client.register(username, password)
        if ('need to add user' in msg):
            canloginLabel = Label(self, text='You can login now...                                               ')
            canloginLabel.place(x=10, y=470)
        elif('user already exists, please choose another user name' in msg):
            canloginLabel = Label(self, text='user already exists, please choose another user name...                        ')
            canloginLabel.place(x=10, y=470)
        else:
            print('wrong')

#don't show GUI labels which are not needed
def destroyGenLabel():
    global genlabel
    if (genlabel is not None):
        genlabel.destroy()
    global finishButton
    if (finishButton is not None):
        finishButton.destroy()

#after login, show user all server options
def serverOptions():
    global window
    window = TK.Toplevel(self)
    window.config(height=400, width=400)

    getUserName()
    hellouserLabel = Label(window, text='Hello '+ username)
    hellouserLabel.place(x=30, y=15)

    uploadButton = Button(window, text="Upload File", width=40, command=uploadFile)
    uploadButton.place(x=75, y=50)
    overwriteButton = Button(window, text='Overwrite File', width=40, command=overwriteFile)
    overwriteButton.place(x=75, y=80)
    downloadButton = Button(window, text='Download File', width=40, command=downloadFile)
    downloadButton.place(x=75, y=110)
    showdirButton = Button(window, text='Show files in directory', width=40, command=showfilesindir)
    showdirButton.place(x=75, y=140)
    deletefileButton = Button(window, text='Delete File', width=40, command=deleteFile)
    deletefileButton.place(x=75, y=170)
    renamefileButton = Button(window, text='Rename file', width=40, command=renameFile)
    renamefileButton.place(x=75, y=200)

    logoutButton = Button(window, text='Logout', command=closeWindow)
    logoutButton.place(x=320, y=15)

#login to server
def login():
    #check user entered both username and password
    if (checkValidity()):
        if (encryptedclient.client.connect()):

            #if (encryptedclient.client.ftp_client.login(username,password)):
            if (encryptedclient.client.login(username, password)):
                if (encryptedclient.isMyFileOnServer()):
                    encryptedclient.downLoadMyFile()
                #files = encryptedclient.showDirFilesEncrypt()
                #if (files != 'No files in this directory') or (not files):
                    canloginLabel =Label(self, text=(encryptedclient.checkIfFilesChange() + '                                  '))
                    canloginLabel.place(x=10, y=470)
                serverOptions()
            else:
                canloginLabel = Label(self, text='Sorry, an Error occured, can\'t login to server                     ')
                canloginLabel.place(x=10, y=470)
        else:
            canloginLabel = Label(self, text='Sorry, an Error occured, can\'t connect to server                       ')
            canloginLabel.place(x=10, y=470)
        # if login succeeded call to serverOptions

def browse():
    path =  tkFileDialog.askopenfilename()
    return path

#upload file to server
def uploadFile():
    global LB
    global LB2
    global LB3
    global newname
    global renameError
    if (renameError is not None):
        renameError.destroy()
    if (LB is not None):
        LB.pack_forget()
    if(LB2 is not None):
        LB2.pack_forget()
    if (LB3 is not None):
        LB3.pack_forget()
    if (values is not None):
        values.destroy()
    if (newname is not None):
        newname.destroy()
    global genlabel
    if (genlabel is not None):
        genlabel.destroy()
    destroyGenLabel()

    global renameLabel
    if (renameLabel is not None):
        renameLabel.destroy()
    global finishButton

    filePath = browse()
    if filePath:
        filename = ntpath.basename(filePath)
        if (encryptedclient.uploadFileEncrypt(filePath)=='already exists'):
            genlabel = Label(window, text= filename + ' alredy exists!! Please choose another file or overwrite')
            genlabel.place(x=10, y=370)

        else:
            genlabel = Label(window, text='Your file: ' + filename +' uploaded successfuly to server')
            genlabel.place(x=10, y=370)

#overwrite file on server
def overwriteFile():
    global renameLabel
    global newname
    global renameError
    if (renameError is not None):
        renameError.destroy()
    if (renameLabel is not None):
        renameLabel.destroy()
    if (newname is not None):
        newname.destroy()
    global LB
    global LB2
    global LB3
    if (LB is not None):
        LB.destroy()
    if(LB2 is not None):
        LB2.destroy()
    if (LB3 is not None):
        LB3.destroy()
    if(values is not None):
        values.destroy()

    destroyGenLabel()

    filePath = browse()
    if filePath:
        filename = ntpath.basename(filePath)
        if (encryptedclient.overwriteFileEncrypt(filePath)):
            uploadLabel = Label(window, text='Your file: ' + filename + ' overwrited successfuly to server')
            uploadLabel.place(x=10, y=370)

#shoe files in directory on server
def showfilesindir():
    global renameLabel
    global newname
    global values
    global renameError
    if (renameError is not None):
        renameError.destroy()
    if (renameLabel is not None):
        renameLabel.destroy()
    if (newname is not None):
        newname.destroy()
    global LB
    global LB2
    global LB3
    if (LB is not None):
        LB.destroy()
    if (LB2 is not None):
        LB2.destroy()
    if (LB3 is not None):
        LB3.destroy()
    if (values is not None):
        values.destroy()
    global finishButton
    destroyGenLabel()
    files = encryptedclient.showDirFilesEncrypt()
    if (files == 'No files in this directory' or not files):
        # label of No files in this directory
        genlabel = Label(window, text='There are no files in your directory...')
        genlabel.place(x=10, y=370)
    else:
        values = Text(window, width=41, height=5, font=('Currier',9))
        for x in files:
            newval = str(x) + '\n'
            values.insert(END, newval)
        values.place(x=75, y=250)

#download file from server
def download():
    global LB
    global  genlabel
    myfile = LB.get(LB.curselection()[0])
    isok = encryptedclient.downloadFileEncrypt(myfile)
    if(not isok):
        genlabel = Label(window, text='File has been changed!!!!')
        genlabel.place(x=10, y=370)
    else:
        genlabel = Label(window, text='Your file: ' + myfile + ' downloaded successfuly from the server')
        genlabel.place(x=10, y=370)


def downloadFile():
    global renameLabel
    global newname
    global renameError
    if (renameError is not None):
        renameError.destroy()
    if (renameLabel is not None):
        renameLabel.destroy()
    if (newname is not None):
        newname.destroy()
    global finishButton
    destroyGenLabel()
    global LB
    LB = Listbox (window, selectmode=SINGLE, width=47, height=5)
    files = encryptedclient.showDirFilesEncrypt()
    for item in files:
        LB.insert(END, item)
    LB.pack(expand=YES)
    LB.place(x=75, y=250)

    finishButton = Button(window, text='Download now', command=download)
    finishButton.place(x=75, y=350)

#delete file from server
def delete():
    global LB2
    myfile = LB2.get(LB2.curselection()[0])
    encryptedclient.deleteFileEncrypt(myfile)

def deleteFile():
    global renameLabel
    global newname
    global renameError
    if (renameError is not None):
        renameError.destroy()
    if (renameLabel is not None):
        renameLabel.destroy()
    if (newname is not None):
        newname.destroy()
    global finishButton
    destroyGenLabel()
    global LB2
    LB2 = Listbox(window, selectmode=SINGLE, width=47, height=5)
    files = encryptedclient.showDirFilesEncrypt()
    for item in files:
        LB2.insert(END, item)
    LB2.pack(expand=YES)
    LB2.place(x=75, y=250)

    finishButton = Button(window, text='Delete now', command=delete)
    finishButton.place(x=75, y=350)

#rename file on server
def rename():
    global LB3
    global newname
    global renameError
    curfile = LB3.get(LB3.curselection()[0])

    #curfile = oldname
  #  newname.insert(curfile)
    changename = newname.get()
    if (curfile is None) or (not curfile) or (changename is None) or (not changename):
        renameError = Label(window, text='Please select file to rename AND enter new name')
        renameError.place(x=10, y=370)
    encryptedclient.renameFileEncrypt(curfile,changename)
    LB3.selection_clear(0, END)

def renameFile():
    global renameLabel
    global finishButton
    destroyGenLabel()
    global LB3
    global newname

    files = encryptedclient.showDirFilesEncrypt()

    LB3 = Listbox(window, selectmode=SINGLE, width=47, height=5)
    for item in files:
        LB3.insert(END, item)
    LB3.pack(expand=YES)
    LB3.place(x=75, y=250)

    '''
    var = StringVar(window)
    var.set(files[0])
    LB3 = OptionMenu(window, var, *files)
    LB3.place(x=75, y=250)
    '''
    newname = Entry(window, width=30)
    newname.place(x=75, y=355)

    renameLabel = Label(window, text='Please enter here the new name:')
    renameLabel.place(x=75, y=335)
    finishButton = Button(window, text='Rename now', command=rename)
    finishButton.place(x=270, y=350)


global LB
global LB2
global LB3
global values
global genlabel
global newname
global renameError
global canloginLabel
canloginLabel = None
genlabel = None
global finishButton
finishButton = None
global renameLabel
renameLabel = None
LB = None
LB2 = None
LB3 = None
values = None
newname = None
renameError = None

loginButton = Button(self, text='Login', command=login)
loginButton.place(x=160, y=250)
loginButton.config(width=20)

registerButton = Button(self, text='Register', command=register)
registerButton.place(x=330, y=250)
registerButton.config(width=20)

usernameLabel = Label(self, text='Username:')
usernameLabel.place(x=160, y=170)
passwordLabel = Label(self, text='Password:')
passwordLabel.place(x=160, y=200)

password = StringVar()
usernameEntry = Entry(self, width=40)
usernameEntry.place(x=240, y=170)
passwordEntry = Entry(self, textvariable=password, show='*', width=40)
passwordEntry.place(x=240, y=200)


self.mainloop()


