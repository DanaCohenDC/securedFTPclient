from ftplib import FTP
from socket import *              # portable socket interface plus constants
import hashlib
import os, random
from pathlib import Path

#this function get key and pad it by concat more chars
def padKey( key):
    size = key.__len__()
    if size % 16 != 0:
        charNumToAdd = (size / 16 + 1) * 16 - size
        for i in range(0, charNumToAdd):
            key = key + random.choice('abcdefghijklmnopqrstuvwxyz')
    return key

#this function return new password
def makeKey(password, i):
    return hashlib.sha256(password + i).hexdigest()

class client():
    def __init__(self):
        self.ftp_client = None
        self.macFile = None
        self.k1 = 0 #password
        self.k2 = 0 #encryption
        self.k3 = 0 #auth
        self.myFile = ''
    #this fucntion register client to server by name and password
    def register(self,username,password):
        self.myFile = str(Path().absolute()) + '\\' +username + "myfiles.txt"
        serverHost = 'localhost'  # server name, or: 'starship.python.net'
        serverPort = 50007  # non-reserved port used by the server
        self.k1 = makeKey(password,'1')
        regMesage = ['register'+ ' '+ username+ ' ' +self.k1]
        sockobj = socket(AF_INET, SOCK_STREAM)  # make a TCP/IP socket object
        sockobj.connect((serverHost, serverPort))  # connect to serve and port

        for line in regMesage:
            sockobj.send(line)  # send line to server over socket
            data = sockobj.recv(1024)  # receive from server: up to 1k
            #print 'Client received:', `data`
        sockobj.close()  # close to send eof to server
        return data

    #this function connect to FTP server
    def connect(self):
        try:
            self.ftp_client = FTP('')
            self.ftp_client.connect('localhost', 21)
            return True
        except Exception:
            return False
    #this function get file name and overwrite file in server if exist
    def overwrite(self,filename):
        if self.exists(filename):
            try:
                self.deleteFile(filename)
                self.uploadFile(filename)
                return True
            except Exception:
                return False
        try:
            self.uploadFile(self.ftp_client, filename)
            return True
        except Exception:
            return False
    #this function return file list that exist in the server
    def showDirFiles(self):
        try:
            files = self.ftp_client.nlst()
        except FTP.error_perm, resp:
            if str(resp) == "550 No files found":
                return "No files in this directory"
            else:
                raise
        return files
    #this funcrion login client to server
    def login(self,userName,password):
        self.myFile = str(Path().absolute()) + '\\' + userName + "myfiles.txt"
        if not os.path.exists(self.myFile ):
            file = open(self.myFile, 'w+')
            file.close()
        print self.myFile
        passw = makeKey(password, '1')
        self.k2 = makeKey(password, '2')
        key32 = self.k2
        key32 = "".join([' ' if i >= len(key32) else key32[i] for i in range(32)])
        self.k2 = key32.encode('utf-8')
        self.k3 = makeKey(password, '3')
        try:
            self.ftp_client.login(userName, passw)
            try:
                self.ftp_client.cwd(userName)  # replace with your directory
            except:
                self.ftp_client.mkd(userName)
                self.ftp_client.cwd(userName)
            return True
        except Exception:
            return False


    #this function get file name and upload it to the server
    def uploadFile(self,filename):
        localfile = open(filename, 'rb')
        self.ftp_client.storbinary('STOR '+filename,localfile)

    #this function get file name and download it to client
    def downloadFile(self, filename):
        #filename = 'testfile.txt' #replace with your file in the directory ('directory_name')
        print filename
        localfile = open(filename, 'wb')
        self.ftp_client.retrbinary('RETR ' + filename, localfile.write, 1024)
        #ftp.quit()
        localfile.close()

    # this function get file name and delete on the server
    def deleteFile(self,fileName):
        if self.exists(fileName):
            self.ftp_client.delete(fileName)
            return 1
        return 0

    # this function get file name and rename it on the server
    def renameFile(self,oldFile,newFile):
        self.ftp_client.rename(oldFile,newFile)

    # this function get file name and check if exist
    def exists(self, filename):
        files=self.ftp_client.nlst()

        if files.__contains__(filename):
            return 1
        return 0
