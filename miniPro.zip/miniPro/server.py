from pyftpdlib.authorizers import DummyAuthorizer, AuthenticationFailed
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
import threading
import hashlib, uuid
import os
from pathlib import Path

desktop = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')
path = str(Path().absolute()) + '\userToAdd.txt'

class DummyAuthorizer(DummyAuthorizer):
    #This function return the salt of user by user name
    def findSalt(self,username):
        file = open(path, 'r+')
        readFile = file.read()
        foundSalt=''
        fileRows = readFile.split('\n')
        for row in fileRows:
            userDetails = row.split(' ')
            if userDetails[0] == username:
                foundSalt = userDetails[2]
                break
        file.close()
        return foundSalt

    #This function check if user name and password is match
    def validate_authentication(self, username, password, handler):
        salt = self.findSalt(username)
        msg = "Authentication failed."
        if not self.has_user(username):
            if username == 'anonymous':
                msg = "Anonymous access not allowed."
            raise AuthenticationFailed(msg)
        if username != 'anonymous':
            hashed_password = hashlib.sha256(password + salt).hexdigest()
            if self.user_table[username]['pwd'] != hashed_password:
                raise AuthenticationFailed(msg)

class ftp_server(threading.Thread):
   def __init__(self):
       self.authorizer = DummyAuthorizer()
       threading.Thread.__init__(self)
       self.init_add_user()

   #This function run the FTP server
   def run(self):
       self.handler = FTPHandler
       self.handler.authorizer = self.authorizer
       self.address = ('0.0.0.0', 21)
       self.server = FTPServer(self.address, self.handler)
       self.server.serve_forever()

   def add_user(self, username, password):
        self.authorizer.add_user(username, password, ".", 'elradfmwM')

    #This funcrtion scan the file user to add and add users to server if needed
   def init_add_user(self):
       if not os.path.exists(path):
           openusertoadd= open(path, 'w+')
           openusertoadd.close()
       file = open(path, 'r+')
       readFile = file.read()
       if readFile=='':
           return
       userpassList = readFile.split('\n')
       filestr = ''
       for user in userpassList:
           if user != '':
               curr = user.split(' ')
               self.add_user(curr[0], curr[1])
       file.close()


