from socket import *  # get socket constructor and constants
import threading
import hashlib, uuid
from pathlib import Path

class register_server(threading.Thread):
    def __init__(self, ftp_server):
        threading.Thread.__init__(self)
        self.ftp_server = ftp_server
        self.myHost = ''  # server machine, '' means local host
        self.myPort = 50007  # listen on a non-reserved port number
        self.sockobj = socket(AF_INET, SOCK_STREAM)  # make a TCP socket object
        self.sockobj.bind((self.myHost, self.myPort))  # bind it to server port number
        self.sockobj.listen(5)  # listen, allow 5 pending connects

    #This function check if user name is already exist
    def checkIfExist(self, Str):
        path = str(Path().absolute()) + '\userToAdd.txt'
        arr = Str.split(' ')
        if arr[0]=="register" :
            username = arr[1]
            flag= False #means doesnt exist
            file = open(path, 'r+')
            readFile = file.read()
            file.close()
            userpassList = readFile.split('\n')
            for user in userpassList:
                curr = user.split(' ')
                if curr[0] == username:
                    flag = True
                    break

            if flag == False:
                salt = uuid.uuid4().hex
                hashed_password = hashlib.sha256(arr[2] + salt).hexdigest()
                self.ftp_server.add_user(username,hashed_password)
                file = open(path, 'a')
                file.write(arr[1]+ ' '+hashed_password+ ' ' + salt +'\n')
                file.close();
                return "need to add user here"
            else:
                file.close();
                return "user already exists, please choose another user name"
        else:
            file.close();
            return "command not valid"
    #This function listen to the port and when get massage of user name check if this user name exist
    def run(self):
        while 1:  # listen until process killed
            connection, address = self.sockobj.accept()  # wait for next client connect
            print 'Server connected by', address  # connection is a new socket
            while 1:
                data = connection.recv(1024)  # read next line on client socket
                if not data: break  # send a reply line to the client
                else:
                    msg = self.checkIfExist(data)

                connection.send('Echo=>' + msg)  # until eof when socket closed
            connection.close()



