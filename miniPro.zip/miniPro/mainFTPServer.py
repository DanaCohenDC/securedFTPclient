from server import ftp_server
from registerServer import register_server
#This file is used for running two threads :
#the ftp server thread
#and the thread which in charge of the connection of clients to server.
try:
    this_ftp = ftp_server()
    this_reg = register_server(this_ftp)
    this_ftp.start() #the server thread
    this_reg.start()
except Exception, e:
    print str(e)